package com.example.aplicacionfinal

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class InicioSesion : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.iniciarsesion)
    }


    fun OnIniciarSesion(view: View){
        val intent= Intent(this,PaginaPrincipal::class.java).apply {  }
        startActivity(intent)
    }

    fun Atras1(view: View){
        val intent= Intent(this,PantallaInicioSesion::class.java).apply {  }
        startActivity(intent)

    }



}