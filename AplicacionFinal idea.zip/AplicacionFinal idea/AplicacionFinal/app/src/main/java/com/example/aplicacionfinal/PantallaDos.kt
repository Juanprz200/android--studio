package com.example.aplicacionfinal

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class PantallaDos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pantallados)
    }

    fun Comenzar(view: View){
        val intent= Intent(this,PantallaTres::class.java).apply {  }
        startActivity(intent)

    }


}