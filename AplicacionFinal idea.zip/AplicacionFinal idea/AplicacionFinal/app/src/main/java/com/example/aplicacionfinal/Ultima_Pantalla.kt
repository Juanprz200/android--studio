package com.example.aplicacionfinal

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class Ultima_Pantalla : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ultima_pantalla)
    }

    fun Atras4(view: View){
        val intent= Intent(this,PaginaPrincipal::class.java).apply {  }
        startActivity(intent)
    }
}