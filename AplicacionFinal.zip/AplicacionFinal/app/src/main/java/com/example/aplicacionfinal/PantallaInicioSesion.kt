package com.example.aplicacionfinal

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class PantallaInicioSesion : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pantallainiciarsesion)
    }

    fun IniciarSesion(view: View){
        val intent= Intent(this,InicioSesion::class.java).apply {  }
        startActivity(intent)
    }

    fun Registrarse(view: View){
        val intent= Intent(this,Registrarse::class.java).apply {  }
        startActivity(intent)
    }




}

