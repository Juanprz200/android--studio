package com.example.aplicacionfinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import kotlinx.*

class Registrarse : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.registrarse)

    }

    fun Atras2(view: View) {
        val intent = Intent(this, PantallaInicioSesion::class.java).apply { }
        startActivity(intent)
    }

    fun Onregistrarse(view: View) {
        val intent = Intent(this, PaginaPrincipal::class.java).apply { }
        startActivity(intent)

    }
}


